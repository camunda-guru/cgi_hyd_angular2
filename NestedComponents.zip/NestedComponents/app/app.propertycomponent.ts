/**
 * Created by BALASUBRAMANIAM on 24-01-2017.
 */
import {Component,Input} from '@angular/core'
import {bootstrap} from '@angular/platform-browser';

@Component(
    {
        selector:'sub-element',
        template:'<p>Customer Name is {{name}}</p>'
    }
)

export class SubComponent
{
   @Input() name:string;
}