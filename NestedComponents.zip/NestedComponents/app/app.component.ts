/**
 * Created by BALASUBRAMANIAM on 24-01-2017.
 */
import {Component} from '@angular/core'
import {bootstrap} from '@angular/platform-browser';

@Component(
    {
        selector:'main-element',
        templateUrl:'app/app.component.html'
    }
)

export class MainComponent
{
   defaultName:string;
   constructor()
   {
        this.defaultName="NASDAQ";
   }
}