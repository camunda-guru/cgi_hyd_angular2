/**
 * Created by BALASUBRAMANIAM on 24-01-2017.
 */
import { NgModule } from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { MainComponent } from './app.component';
import { SubComponent } from './app.propertycomponent';


@NgModule({
    imports: [
        BrowserModule

    ],
    declarations: [MainComponent,SubComponent],
    exports: [MainComponent],
    bootstrap: [MainComponent]
})
export class AppModule {
}
