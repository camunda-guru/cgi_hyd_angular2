/**
 * Created by BALASUBRAMANIAM on 24-01-2017.
 */
import {Component} from '@angular/core'
import {bootstrap} from '@angular/platform-browser';

@Component({
   selector:'calculate-interest',
   templateUrl:'app/app.component.html'
})


export class AppComponent
{
    principal=10000;
    roi=0.08;
    noy=4;
    simpleInterest=0;

    onChange(p:number,r:number,y:number)
    {
      console.log(p);
      console.log(r);
      console.log(y);
      this.simpleInterest=p*r*y;
    }


}