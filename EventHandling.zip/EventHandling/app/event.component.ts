/**
 * Created by BALASUBRAMANIAM on 24-01-2017.
 */
import {Component,EventEmitter,Input,Output} from '@angular/core'
import {bootstrap} from '@angular/platform-browser';

@Component({
    selector:'calculate',
    templateUrl:'app/event.component.html'
})


export class EventComponent
{
    @Input() IPrincipal;
    @Input() IROI;
    @Input() INOY;
    @Output() result= new EventEmitter<number>()
    calculateResult()
    {
       this.result.emit(this.IPrincipal,this.IROI,this.INOY);
    }

}