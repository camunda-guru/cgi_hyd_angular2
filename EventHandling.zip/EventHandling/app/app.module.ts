/**
 * Created by BALASUBRAMANIAM on 24-01-2017.
 */
import { NgModule } from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { EventComponent } from './event.component';
@NgModule({
    imports: [
        BrowserModule,

    ],
    declarations: [AppComponent,EventComponent],
    exports: [AppComponent],
    bootstrap: [AppComponent]
})
export class AppModule {
}
