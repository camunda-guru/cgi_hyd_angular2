/**
 * Created by BALASUBRAMANIAM on 23-01-2017.
 */

class Program
{
    static  main():void
    {
        console.log('main... invoked');
    }
}

Program.main();