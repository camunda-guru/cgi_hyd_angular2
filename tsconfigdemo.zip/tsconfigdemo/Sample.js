/**
 * Created by BALASUBRAMANIAM on 23-01-2017.
 */
var Program = (function () {
    function Program() {
    }
    Program.main = function () {
        console.log('main... invoked');
    };
    return Program;
}());
Program.main();
//# sourceMappingURL=Sample.js.map