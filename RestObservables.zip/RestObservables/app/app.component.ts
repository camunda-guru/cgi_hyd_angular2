/**
 * Created by BALASUBRAMANIAM on 24-01-2017.
 */
import {Component} from '@angular/core'
import {bootstrap} from '@angular/platform-browser';
import {Http} from '@angular/http';
import 'rxjs/Rx';
@Component(
    {
        selector:'rest-element',
        template:`
        <p>Data from Rest Service</p>
        <table>
         <tr *ngFor="let user of users">
            <td>{{user.id}}</td>
             <td>{{user.name}}</td>
              <td>{{user.email}}</td>
           </tr>
         </table>
`
    }
)

export class MainComponent
{
   users=[];
  constructor(http:Http)
    {
        http.get('http://jsonplaceholder.typicode.com/users/')
            .flatMap((data) => data.json())

            .subscribe((data) => {
                this.users.push(data);

            });
     }
}