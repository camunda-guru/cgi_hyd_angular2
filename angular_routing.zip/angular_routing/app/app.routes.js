"use strict";
var router_1 = require('@angular/router');
var component_one_1 = require('./component-one');
var component_two_1 = require('./component-two');
exports.routes = [
    { path: '', redirectTo: 'component-one', pathMatch: 'full' },
    { path: 'component-one', component: component_one_1["default"] },
    { path: 'component-two/:id', component: component_two_1["default"] }
];
exports.appRoutingProviders = [];
exports.routing = router_1.RouterModule.forRoot(exports.routes);
//# sourceMappingURL=app.routes.js.map