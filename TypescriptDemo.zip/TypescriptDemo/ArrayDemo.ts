/**
 * Created by BALASUBRAMANIAM on 23-01-2017.
 */
class Food
{
    foodItems:any;
    constructor(items)
    {
       this.foodItems=Array.isArray(items)?items:[];
    }

    getFoodItems()
    {
         this.foodItems.forEach((item,i)=>console.log
         (i,'=>',item));
    }
}

var vegFood=new Food(['idly',10,'sambar',15,'rice',67,'chutney',true]);
vegFood.getFoodItems();

