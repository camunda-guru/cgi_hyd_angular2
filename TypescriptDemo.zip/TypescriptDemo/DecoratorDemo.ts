/**
 * Created by BALASUBRAMANIAM on 23-01-2017.
 */
function logStatus(target: any, propertyKey:
    string, parameterIndex: number)
{
   console.log(propertyKey);
   console.log(parameterIndex);
}


class Workshop
{

    getStatus(status:boolean,@logStatus program:string)
    {
        console.log(status,program);
    }
}
var obj =new Workshop();
obj.getStatus(true,'Angular2 Workshop');


