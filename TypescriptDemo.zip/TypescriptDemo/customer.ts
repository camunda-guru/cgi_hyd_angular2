/**
 * Created by BALASUBRAMANIAM on 23-01-2017.
 */
console.log("Testing typescript....");
enum Gender
{
    Female,Male,TransGender
}

class Customer
{
    private firstName:string;
   private lastName:string;
   private customerId:number;
   private gender:Gender;
    constructor(fname,lname,id,gen)
    {
        this.firstName=fname;
        this.lastName=lname;
        this.customerId=id;
        this.gender=gen;
    }

    getCustomerDetails()
    {
        return this.firstName+"->"+this.lastName+"->"+ Gender[this.gender];
    }

    printTemplates()
    {
        console.log(`First name of the person is ${this.firstName}
        and lastname with ${this.lastName}`);
    }

}

var goldCustomer = new Customer('Ashok','Kumar',43875687,Gender.Female);
console.log(goldCustomer.getCustomerDetails());
goldCustomer.printTemplates();
class HighValuedCustomer extends Customer
{
    offer:number;
    constructor(fname,lname,id,gen,offerValue)
    {
        super(fname,lname,id,gen);
        this.offer=offerValue;
    }
    getOffer()
    {
        return this.offer;
    }
}

var obj =new HighValuedCustomer('Suman','Sekar',3495,Gender.Male,0.6);
console.log(obj.getCustomerDetails(),'=>',
    obj.getOffer());

var name = 'Sam';
var age = 42;
console.log(`hello my name is ${name}, and I am ${age} years old`);