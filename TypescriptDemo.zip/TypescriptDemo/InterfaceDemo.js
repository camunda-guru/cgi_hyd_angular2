var ClubMember = (function () {
    function ClubMember(id, typeData) {
        this.memberId = id;
        this.type = typeData;
    }
    ClubMember.prototype.getData = function () {
        return this.memberId + "=>" + this.type;
    };
    ClubMember.prototype.reset = function () {
        this.memberId = 0;
    };
    return ClubMember;
}());
var clubObj = new ClubMember(438657, 'Platinum');
console.log(clubObj.getData());
clubObj.reset();
console.log(clubObj.getData());
/*
function AddMember(member:Member)
{
    return member.memberId + "=>"+member.type;
}

var platinumMember={memberId:43976579,type:'Platinum'};

console.log(AddMember(platinumMember));
    */
//# sourceMappingURL=InterfaceDemo.js.map