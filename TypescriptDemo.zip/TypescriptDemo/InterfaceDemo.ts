/**
 * Created by BALASUBRAMANIAM on 23-01-2017.
 */
interface Member
{
    memberId;
    type;
    reset():void;
}

class ClubMember implements Member
{
    memberId;
    type;
    constructor(id,typeData)
    {
        this.memberId=id;
        this.type=typeData;
    }
    getData()
    {
        return this.memberId+"=>"+this.type;
    }
    reset()
    {
        this.memberId=0;
    }
}

var clubObj = new ClubMember(438657,'Platinum');
console.log(clubObj.getData());
clubObj.reset();
console.log(clubObj.getData());
/*
function AddMember(member:Member)
{
    return member.memberId + "=>"+member.type;
}

var platinumMember={memberId:43976579,type:'Platinum'};

console.log(AddMember(platinumMember));
    */
