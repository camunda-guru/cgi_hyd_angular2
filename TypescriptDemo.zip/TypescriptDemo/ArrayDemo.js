/**
 * Created by BALASUBRAMANIAM on 23-01-2017.
 */
var Food = (function () {
    function Food(items) {
        this.foodItems = Array.isArray(items) ? items : [];
    }
    Food.prototype.getFoodItems = function () {
        this.foodItems.forEach(function (item, i) { return console.log(i, '=>', item); });
    };
    return Food;
}());
var vegFood = new Food(['idly', 10, 'sambar', 15, 'rice', 67, 'chutney', true]);
vegFood.getFoodItems();
//# sourceMappingURL=ArrayDemo.js.map