var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
 * Created by BALASUBRAMANIAM on 23-01-2017.
 */
console.log("Testing typescript....");
var Gender;
(function (Gender) {
    Gender[Gender["Female"] = 0] = "Female";
    Gender[Gender["Male"] = 1] = "Male";
    Gender[Gender["TransGender"] = 2] = "TransGender";
})(Gender || (Gender = {}));
var Customer = (function () {
    function Customer(fname, lname, id, gen) {
        this.firstName = fname;
        this.lastName = lname;
        this.customerId = id;
        this.gender = gen;
    }
    Customer.prototype.getCustomerDetails = function () {
        return this.firstName + "->" + this.lastName + "->" + Gender[this.gender];
    };
    Customer.prototype.printTemplates = function () {
        console.log();
    };
    return Customer;
}());
var goldCustomer = new Customer('Ashok', 'Kumar', 43875687, Gender.Female);
console.log(goldCustomer.getCustomerDetails());
var HighValuedCustomer = (function (_super) {
    __extends(HighValuedCustomer, _super);
    function HighValuedCustomer(fname, lname, id, gen, offerValue) {
        var _this = _super.call(this, fname, lname, id, gen) || this;
        _this.offer = offerValue;
        return _this;
    }
    HighValuedCustomer.prototype.getOffer = function () {
        return this.offer;
    };
    return HighValuedCustomer;
}(Customer));
var obj = new HighValuedCustomer('Suman', 'Sekar', 3495, Gender.Male, 0.6);
console.log(obj.getCustomerDetails(), '=>', obj.getOffer());
//# sourceMappingURL=customer.js.map