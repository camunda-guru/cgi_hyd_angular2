"use strict";
/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
var router_1 = require('@angular/router');
var app_user_1 = require('./app.user');
var app_userdetail_1 = require('./app.userdetail');
exports.routes = [
    { path: '', redirectTo: 'component-one', pathMatch: 'full' },
    { path: 'user', component: app_user_1["default"] },
    { path: 'user-detail/:id', component: app_userdetail_1["default"] }
];
exports.appRoutingProviders = [];
exports.routing = router_1.RouterModule.forRoot(exports.routes);
//# sourceMappingURL=app.route.js.map