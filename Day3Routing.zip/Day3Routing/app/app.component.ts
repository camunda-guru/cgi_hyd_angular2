/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
import {Component} from '@angular/core';

@Component({
    selector: 'app',
    template: `
    <nav>
       <div><user-data></user-data> </div>
      <div [routerLink]="['/user-details', 1]"></div>
    </nav>
    <div style="color: green; margin-top: 1rem;">Outlet:</div>
    <div style="border: 2px solid green; padding: 1rem;">
      <router-outlet></router-outlet>
    </div>
  `
})
export class AppComponent {

}