/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
import { Routes, RouterModule } from '@angular/router';
import UserComponent from './app.user';
import UserDetailComponent from './app.userdetail';

export const routes: Routes = [
    { path: '', redirectTo: 'component-one', pathMatch: 'full' },
    { path: 'user', component: UserComponent},
    { path: 'user-detail/:id', component: UserDetailComponent }
];

export const appRoutingProviders: any[] = [

];

export const routing = RouterModule.forRoot(routes);