/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
import {Component} from '@angular/core';
import {Http} from '@angular/http';
import 'rxjs/Rx';

@Component({
    selector: 'user-data',
    templateUrl: 'app/user-template.html'
})
export default class UserComponent {
    private users = [];


    constructor(http: Http) {

        http.get('http://jsonplaceholder.typicode.com/users/')
            .flatMap((data) => data.json())
            .subscribe((data) => {
                this.users.push(data);
            });
    }

}