/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component.ts';
import { routing, appRoutingProviders } from './app.route';
import UserComponent from './app.user';
import UserDeailComponent from './app.userdetail';

@NgModule({
    imports: [
        BrowserModule,
        routing,
        HttpModule
    ],
    declarations: [
        AppComponent,
        UserComponent,
        UserDeailComponent
    ],
    providers: [
        appRoutingProviders
    ],
    bootstrap: [ AppComponent ]
})
export class AppModule {
}

