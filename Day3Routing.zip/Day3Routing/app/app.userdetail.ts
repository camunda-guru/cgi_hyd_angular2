/**
 * Created by BALASUBRAMANIAM on 06-01-2017.
 */
import {Component,Input} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {Http} from '@angular/http';
@Component({
    selector: 'user-detail',
    templateUrl: 'app/userdetail-template.html'
})
export default class UserDetailComponent {
    private userDetail;
    private id;
    private routeObj;
    private sub;
    private httpObj;

    constructor(http: Http, route: ActivatedRoute) {
          this.routeObj=route;
          this.httpObj=http;

    }
    private ngOnInit() {
        this.sub = this.routeObj.params.subscribe(params => {
            this.id = +params['id']; // (+) converts string 'id' to a number
        });
        this.httpObj.get('http://jsonplaceholder.typicode.com/users/'+this.id)
            .flatMap((data) => data.json())
            .subscribe((data) => {
                this.userDetail=data;
            });

    }

    private ngOnDestroy() {
        this.sub.unsubscribe();
    }
}





