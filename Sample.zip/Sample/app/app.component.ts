import {Component} from 'angular2/core';
@Component({
    selector: 'main-app',
   template: '<h1>Hey! First Component</h1>'
})
export class AppComponent{
    constructor() {}
}