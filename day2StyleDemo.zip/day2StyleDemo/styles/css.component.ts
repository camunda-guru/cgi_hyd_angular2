/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
import { Component } from '@angular/core';

@Component({
    selector: 'css',
    template: `
    <div  style="padding: 1rem"
        [ngStyle]="{ 
          color: 'green',
          'font-weight': 'bold',
           border:'2px solid blue',
           'text-align':'center'
        }">
        <ng-content></ng-content>
    </div>
  `
})
export class CSSComponent {
    //borderStyle = '1px solid black';
}
