/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './styles.module';

platformBrowserDynamic().bootstrapModule(AppModule);