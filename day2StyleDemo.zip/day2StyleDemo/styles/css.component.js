"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
var core_1 = require('@angular/core');
var CSSComponent = (function () {
    function CSSComponent() {
    }
    CSSComponent = __decorate([
        core_1.Component({
            selector: 'css',
            template: "\n    <div  style=\"padding: 1rem\"\n        [ngStyle]=\"{ \n          color: 'green',\n          'font-weight': 'bold',\n           border:'2px solid blue',\n           'text-align':'center'\n        }\">\n        <ng-content></ng-content>\n    </div>\n  "
        })
    ], CSSComponent);
    return CSSComponent;
}());
exports.CSSComponent = CSSComponent;
//# sourceMappingURL=css.component.js.map