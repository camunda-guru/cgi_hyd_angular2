/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
import { Component } from '@angular/core';

@Component({
    selector: 'style-element',
    template: '<css>SriRam Software, Oliver Road, Mylapore</css>'
})
export class AppComponent {

}