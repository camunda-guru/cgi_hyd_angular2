"use strict";
/**
 * Created by BALASUBRAMANIAM on 05-01-2017.
 */
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var styles_module_1 = require('./styles.module');
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(styles_module_1.AppModule);
//# sourceMappingURL=main.js.map