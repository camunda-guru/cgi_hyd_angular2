"use strict";
/**
 * Created by BALASUBRAMANIAM on 24-01-2017.
 */
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var form_module_1 = require("./form.module");
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(form_module_1.AppModule);
//# sourceMappingURL=main.js.map