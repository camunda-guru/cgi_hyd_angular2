/**
 * Created by BALASUBRAMANIAM on 24-01-2017.
 */
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic'
import { AppModule } from './form.module'

platformBrowserDynamic().bootstrapModule(AppModule)