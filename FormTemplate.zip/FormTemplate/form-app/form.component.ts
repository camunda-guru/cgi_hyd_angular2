/**
 * Created by BALASUBRAMANIAM on 24-01-2017.
 */
import {Component} from '@angular/core'
import {bootstrap} from '@angular/platform-browser';

@Component(
    {
     selector:'form-root',
     templateUrl:'form-app/form.component.html'
    }
)

export class AppComponent
{
    formValue = JSON.stringify({});

    onSubmit (form: NgForm) {

        this.formValue = JSON.stringify(form.value);
        console.log( this.formValue)
    }
}